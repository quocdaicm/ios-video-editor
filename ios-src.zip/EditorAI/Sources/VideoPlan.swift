import Foundation
import AVFoundation

struct RenderError: LocalizedError {
    let message: String
    init(_ m: String) { message = m }
    var errorDescription: String? { message }
}

struct Cue {
    var id: Int
    var start: Double
    var end: Double
    var text: String
}

struct TimelineItem: Identifiable {
    var index: Int
    var id: String
    var subtitles: [Int]
    var image: URL
    var motionType: String
    var motionStrength: String
    var start: Double
    var end: Double
    var duration: Double
}

struct RenderPlan {
    var timeline: [TimelineItem]
    var cues: [Int: Cue]
    var audio: URL
    var audioDuration: Double
    var totalDuration: Double { timeline.last?.end ?? audioDuration }
}

/// Port từ video_creator.py: parse_srt_file, find_image_for_scene, compute_timeline.
enum VideoPlanner {

    static func parseSRT(_ raw: String) -> [Int: Cue] {
        var text = raw.replacingOccurrences(of: "\u{FEFF}", with: "")
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")
        text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        text = text.replacingOccurrences(of: "\\n[ \\t]*\\n", with: "\u{1}", options: .regularExpression)
        var cues: [Int: Cue] = [:]
        let timeRe = try! NSRegularExpression(pattern: "(\\d+:\\d+:\\d+[,\\.]\\d+)\\s*-->\\s*(\\d+:\\d+:\\d+[,\\.]\\d+)")
        for block in text.components(separatedBy: "\u{1}") {
            let lines = block.components(separatedBy: "\n")
                .map { $0.trimmingCharacters(in: .whitespaces) }
                .filter { !$0.isEmpty }
            guard lines.count >= 2, let id = Int(lines[0]) else { continue }
            let ns = lines[1] as NSString
            guard let m = timeRe.firstMatch(in: lines[1], range: NSRange(location: 0, length: ns.length)),
                  let s = SRT.parse(ns.substring(with: m.range(at: 1))),
                  let e = SRT.parse(ns.substring(with: m.range(at: 2))) else { continue }
            let body = lines.count > 2 ? lines[2...].joined(separator: " ") : ""
            cues[id] = Cue(id: id, start: s, end: e, text: body)
        }
        return cues
    }

    static func findImage(in files: [URL], sceneID: String, index: Int) -> URL? {
        let target = sceneID.uppercased()
        let sorted = files.sorted { $0.lastPathComponent < $1.lastPathComponent }
        var matched: [URL] = []
        for f in sorted {
            let stem = f.deletingPathExtension().lastPathComponent.uppercased()
            let prefix = stem.split(whereSeparator: { $0 == "-" || $0 == "_" }).first.map(String.init) ?? stem
            if prefix.trimmingCharacters(in: .whitespaces) == target { matched.append(f); continue }
            if stem.range(of: "^\(NSRegularExpression.escapedPattern(for: target))([-_.]|$)", options: .regularExpression) != nil {
                matched.append(f)
            }
        }
        if !matched.isEmpty {
            return matched.first(where: { $0.lastPathComponent.lowercased().contains("clean") }) ?? matched[0]
        }
        if index - 1 >= 0 && index - 1 < sorted.count { return sorted[index - 1] }
        return nil
    }

    static func audioDuration(_ url: URL) async throws -> Double {
        let asset = AVURLAsset(url: url)
        let d = try await asset.load(.duration)
        let s = CMTimeGetSeconds(d)
        guard s.isFinite, s > 0 else { throw RenderError("Không đo được thời lượng file âm thanh.") }
        return s
    }

    static func build(project: Project) async throws -> RenderPlan {
        guard let scenesText = try? String(contentsOf: project.scenesURL, encoding: .utf8),
              !scenesText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw RenderError("Chưa có kịch bản. Vào tab Kịch bản để nhập và lưu.")
        }
        var scenes: [SceneItem]
        do { scenes = try SceneParser.parse(text: scenesText) }
        catch { throw RenderError("Kịch bản không hợp lệ: \(error.localizedDescription)") }
        if scenes.isEmpty { throw RenderError("Kịch bản chưa có phân cảnh.") }

        guard let audio = project.latestVoice else {
            throw RenderError("Chưa có file giọng đọc. Tạo ở tab Giọng TTS rồi bấm Lưu vào dự án.")
        }
        var cues: [Int: Cue] = [:]
        if let srt = project.latestSRT, let t = try? String(contentsOf: srt, encoding: .utf8) {
            cues = parseSRT(t)
        }
        let available = cues.keys.sorted()
        let timed = scenes.contains { $0.startAt != nil }

        if timed && !available.isEmpty {
            for sc in scenes where sc.subtitles.contains(where: { !available.contains($0) }) {
                throw RenderError("\(sc.id) tham chiếu subtitle_id không có trong SRT.")
            }
        }
        if !timed && !available.isEmpty && !scenes.contains(where: { !$0.subtitles.isEmpty }) {
            let n = scenes.count
            let chunk = available.count / n
            let rem = available.count % n
            var cur = 0
            for i in 0..<n {
                let take = chunk + (i < rem ? 1 : 0)
                scenes[i].subtitles = Array(available[cur..<(cur + take)])
                cur += take
            }
        }

        let total = try await audioDuration(audio)
        let images = project.cleanImages
        var tl: [TimelineItem] = []
        for (i, sc) in scenes.enumerated() {
            guard let img = findImage(in: images, sceneID: sc.id, index: i + 1) else {
                throw RenderError("Không tìm thấy ảnh cho \(sc.id). Đặt tên ảnh dạng \(sc.id)_clean.png trong images/clean.")
            }
            let start: Double
            if let s = sc.startAt { start = SRT.parse(s) ?? 0 }
            else if i == 0 { start = 0 }
            else if let first = sc.subtitles.first, let cue = cues[first] { start = cue.start }
            else { start = (tl.last?.start ?? 0) + 1.0 }
            tl.append(TimelineItem(index: i + 1, id: sc.id, subtitles: sc.subtitles, image: img,
                                   motionType: sc.motionType, motionStrength: sc.motionStrength,
                                   start: start, end: 0, duration: 0))
        }
        for i in scenes.indices {
            var end: Double
            if let e = scenes[i].endAt {
                end = (e == "AUDIO_END") ? total : (SRT.parse(e) ?? total)
            } else if i < scenes.count - 1 {
                end = tl[i + 1].start
            } else {
                end = max(total, tl[i].start + 0.5)
            }
            var dur = ((end - tl[i].start) * 1000).rounded() / 1000
            if dur <= 0 && scenes[i].endAt != nil {
                throw RenderError("Thời lượng âm thanh không đủ cho \(scenes[i].id).")
            }
            if dur <= 0 { dur = 0.5; end = tl[i].start + dur }
            tl[i].end = end
            tl[i].duration = dur
        }
        return RenderPlan(timeline: tl, cues: cues, audio: audio, audioDuration: total)
    }
}
