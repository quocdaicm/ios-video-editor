import SwiftUI
import AVFoundation

struct TTSParams {
    var provider: String
    var model: String
    var language: String
    var voiceID: String
    var voiceSettings: [String: Any]
    var text: String
    var exportSRT: Bool
}

@MainActor
final class AudioPlayerModel: ObservableObject {
    @Published var isPlaying = false
    private var player: AVAudioPlayer?
    private var remote: AVPlayer?
    private var endObserver: NSObjectProtocol?

    private func activateSession() {
        try? AVAudioSession.sharedInstance().setCategory(.playback)
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    func toggle(fileURL: URL) {
        if isPlaying { stop(); return }
        activateSession()
        player = try? AVAudioPlayer(contentsOf: fileURL)
        player?.play()
        isPlaying = player?.isPlaying ?? false
    }

    func toggle(remoteURL: String) {
        if isPlaying { stop(); return }
        guard let url = URL(string: remoteURL) else { return }
        activateSession()
        let item = AVPlayerItem(url: url)
        remote = AVPlayer(playerItem: item)
        endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.stop() }
        }
        remote?.play()
        isPlaying = true
    }

    func stop() {
        player?.stop()
        player = nil
        remote?.pause()
        remote = nil
        if let o = endObserver { NotificationCenter.default.removeObserver(o) }
        endObserver = nil
        isPlaying = false
    }
}

@MainActor
final class TTSViewModel: ObservableObject {
    @Published var isRunning = false
    @Published var status = ""
    @Published var errorText: String?
    @Published var audioURL: URL?
    @Published var srtURL: URL?
    @Published var balance: Int?

    private let client = VibiClient.shared
    private var task: Task<Void, Never>?

    static var documentsDir: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    func refreshBalance() async {
        guard client.isConfigured else { balance = nil; return }
        balance = try? await client.credits()
    }

    func start(_ p: TTSParams) {
        task?.cancel()
        task = Task { await generate(p) }
    }

    func cancel() {
        task?.cancel()
    }

    private func audioDuration(_ data: Data) async -> Double {
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("chunk_\(UUID().uuidString).mp3")
        defer { try? FileManager.default.removeItem(at: tmp) }
        guard (try? data.write(to: tmp)) != nil else { return 0 }
        let asset = AVURLAsset(url: tmp)
        if let d = try? await asset.load(.duration) {
            let s = CMTimeGetSeconds(d)
            return s.isFinite ? s : 0
        }
        return 0
    }

    private func generate(_ p: TTSParams) async {
        isRunning = true
        errorText = nil
        audioURL = nil
        srtURL = nil
        defer { isRunning = false; status = "" }

        do {
            let chunks = VibiClient.splitLongText(p.text)
            var audio = Data()
            var srt = ""
            var srtIndex = 1
            var offset = 0.0

            for (i, chunk) in chunks.enumerated() {
                status = chunks.count > 1 ? "Đang tạo đoạn \(i + 1)/\(chunks.count)..." : "Đang gửi yêu cầu..."
                let id = try await client.createTTSTask(
                    voiceID: p.voiceID, text: chunk, modelID: p.model, language: p.language,
                    provider: p.provider, voiceSettings: p.voiceSettings, exportTranscript: p.exportSRT)
                status = chunks.count > 1 ? "Chờ server xử lý đoạn \(i + 1)/\(chunks.count)..." : "Chờ server xử lý..."
                let done = try await client.waitForTask(id)
                let result = done["result"] as? [String: Any]
                guard let audioStr = result?["audio_url"] as? String else {
                    throw VibiError(message: "Task hoàn thành nhưng không tìm thấy audio_url trong kết quả!")
                }
                let chunkAudio = try await client.download(audioStr)
                audio.append(chunkAudio)

                if p.exportSRT, let srtStr = result?["srt_url"] as? String,
                   let sdata = try? await client.download(srtStr),
                   let stext = String(data: sdata, encoding: .utf8) {
                    srt += SRT.shifted(stext, by: offset, startIndex: &srtIndex)
                }
                if chunks.count > 1 && i < chunks.count - 1 {
                    offset += await audioDuration(chunkAudio)
                }
            }

            let fmt = DateFormatter()
            fmt.dateFormat = "yyyyMMdd_HHmmss"
            let dir = Self.documentsDir
                .appendingPathComponent("Voice", isDirectory: true)
                .appendingPathComponent(fmt.string(from: Date()), isDirectory: true)
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)

            let mp3 = dir.appendingPathComponent("voice.mp3")
            try audio.write(to: mp3)
            audioURL = mp3
            if !srt.isEmpty {
                let srtFile = dir.appendingPathComponent("voice.srt")
                try srt.write(to: srtFile, atomically: true, encoding: .utf8)
                srtURL = srtFile
            }
            status = "Xong!"
            await refreshBalance()
        } catch is CancellationError {
            errorText = "Đã hủy."
        } catch {
            errorText = error.localizedDescription
        }
    }
}
