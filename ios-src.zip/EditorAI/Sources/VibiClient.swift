import Foundation

struct VibiError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct VoiceInfo: Identifiable, Hashable {
    let id: String
    let name: String
    let gender: String
    let language: String
    let previewURL: String
    let desc: String
}

enum SRT {
    static func parse(_ s: String) -> Double? {
        let parts = s.trimmingCharacters(in: .whitespaces)
            .replacingOccurrences(of: ",", with: ".")
            .components(separatedBy: ":")
        guard parts.count == 3,
              let h = Double(parts[0]), let m = Double(parts[1]), let sec = Double(parts[2]) else { return nil }
        return h * 3600 + m * 60 + sec
    }

    static func format(_ t: Double) -> String {
        let total = max(0, Int((t * 1000).rounded()))
        let ms = total % 1000
        let s = (total / 1000) % 60
        let m = (total / 60000) % 60
        let h = total / 3600000
        return String(format: "%02d:%02d:%02d,%03d", h, m, s, ms)
    }

    /// Dịch thời gian của file SRT một đoạn `offset` giây và đánh số lại.
    static func shifted(_ text: String, by offset: Double, startIndex: inout Int) -> String {
        let blocks = text.replacingOccurrences(of: "\r\n", with: "\n").components(separatedBy: "\n\n")
        var out: [String] = []
        for block in blocks {
            let lines = block.components(separatedBy: "\n")
            guard let ti = lines.firstIndex(where: { $0.contains("-->") }) else { continue }
            let parts = lines[ti].components(separatedBy: "-->")
            guard parts.count == 2, let a = parse(parts[0]), let b = parse(parts[1]) else { continue }
            let body = lines[(ti + 1)...].joined(separator: "\n")
            out.append("\(startIndex)\n\(format(a + offset)) --> \(format(b + offset))\n\(body)")
            startIndex += 1
        }
        return out.isEmpty ? "" : out.joined(separator: "\n\n") + "\n\n"
    }
}

final class VibiClient {
    static let shared = VibiClient()

    var apiKey: String {
        (UserDefaults.standard.string(forKey: "vibi_api_key") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var baseURL: String {
        let b = (UserDefaults.standard.string(forKey: "vibi_api_base") ?? "").trimmingCharacters(in: CharacterSet(charactersIn: "/ \n"))
        return b.isEmpty ? "https://api.vibi.pro" : b
    }

    var isConfigured: Bool { !apiKey.isEmpty }

    // MARK: - HTTP

    private func request(_ method: String, _ path: String,
                         query: [String: String] = [:],
                         body: [String: Any]? = nil,
                         timeout: TimeInterval = 20) async throws -> [String: Any] {
        guard isConfigured else {
            throw VibiError(message: "Voice API Key chưa được cài đặt! Vào tab Cài đặt để nhập API Key.")
        }
        guard var comps = URLComponents(string: baseURL + path) else {
            throw VibiError(message: "Địa chỉ API không hợp lệ.")
        }
        if !query.isEmpty {
            comps.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        }
        guard let url = comps.url else { throw VibiError(message: "Địa chỉ API không hợp lệ.") }

        var req = URLRequest(url: url)
        req.httpMethod = method
        req.timeoutInterval = timeout
        req.setValue(apiKey, forHTTPHeaderField: "xi-api-key")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("EditorAI-iOS/1.0", forHTTPHeaderField: "User-Agent")
        if let body = body {
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
        }

        let data: Data
        let resp: URLResponse
        do {
            (data, resp) = try await URLSession.shared.data(for: req)
        } catch {
            throw VibiError(message: "Lỗi mạng khi gọi Voice API: \(error.localizedDescription)")
        }
        let status = (resp as? HTTPURLResponse)?.statusCode ?? 0
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]

        if status == 401 {
            throw VibiError(message: "API Key Voice API không chính xác hoặc đã hết hạn (Mã lỗi 401)!")
        }
        if !(200...299).contains(status) {
            let msg = (json["message"] as? String) ?? (json["error"] as? String)
                ?? String(data: data, encoding: .utf8) ?? "Không rõ lỗi"
            throw VibiError(message: "Yêu cầu thất bại [HTTP \(status)]: \(msg)")
        }
        return json
    }

    // MARK: - Tài khoản

    func credits() async throws -> Int {
        let info = try await request("GET", "/v1/auth/me", timeout: 15)
        if let v = info["credit_balance"] as? Int { return v }
        if let v = info["credit_balance"] as? Double { return Int(v) }
        if let v = info["credits"] as? Int { return v }
        if let v = info["credits"] as? Double { return Int(v) }
        return 0
    }

    // MARK: - Thư viện giọng

    /// page tính từ 0.
    func searchVoices(provider: String, search: String, page: Int) async throws -> (voices: [VoiceInfo], hasMore: Bool) {
        let q = search.trimmingCharacters(in: .whitespaces)
        switch provider {
        case "minimax":
            var query: [String: String] = ["page": "\(page + 1)", "page_size": "30"]
            if !q.isEmpty { query["search"] = q }
            let data = try await request("GET", "/v1/minimax/system-voices", query: query, timeout: 15)
            let list = data["voice_list"] as? [[String: Any]] ?? []
            let voices: [VoiceInfo] = list.map { v in
                let tags = v["tag_list"] as? [String] ?? []
                let gender = tags.first(where: { ["male", "female"].contains($0.lowercased()) })?.capitalized ?? "-"
                let vid = (v["voice_id"] as? String) ?? (v["uniq_id"] as? String) ?? ""
                return VoiceInfo(id: vid,
                                 name: v["voice_name"] as? String ?? "",
                                 gender: gender,
                                 language: tags.isEmpty ? "-" : tags.joined(separator: ", "),
                                 previewURL: v["sample_audio"] as? String ?? "",
                                 desc: v["description"] as? String ?? "")
            }
            return (voices.filter { !$0.id.isEmpty }, data["has_more"] as? Bool ?? false)

        case "capcut":
            var query: [String: String] = ["page": "\(page + 1)", "page_size": "30"]
            if !q.isEmpty { query["search"] = q }
            let data = try await request("GET", "/v1/capcut/system-voices", query: query, timeout: 15)
            let list = data["voice_list"] as? [[String: Any]] ?? []
            let voices: [VoiceInfo] = list.map { v in
                let tags = v["tags"] as? [String] ?? []
                let lang = "[\(v["language"] as? String ?? "-")] " + tags.joined(separator: ", ")
                return VoiceInfo(id: "\(v["voice_id"] ?? "")",
                                 name: v["name"] as? String ?? "",
                                 gender: (v["gender"] as? String ?? "-").capitalized,
                                 language: lang,
                                 previewURL: v["preview_url"] as? String ?? "",
                                 desc: v["description"] as? String ?? "")
            }
            return (voices.filter { !$0.id.isEmpty }, data["has_more"] as? Bool ?? false)

        default:
            var query: [String: String] = ["page_size": "30", "page": "\(page)", "sort": "trending"]
            if !q.isEmpty { query["search"] = q }
            let data = try await request("GET", "/v1/shared-voices", query: query, timeout: 15)
            let list = data["voices"] as? [[String: Any]] ?? []
            let voices: [VoiceInfo] = list.map { v in
                VoiceInfo(id: v["voice_id"] as? String ?? "",
                          name: v["name"] as? String ?? "",
                          gender: (v["gender"] as? String ?? "-").capitalized,
                          language: (v["language"] as? String) ?? (v["accent"] as? String) ?? "en",
                          previewURL: v["preview_url"] as? String ?? "",
                          desc: v["description"] as? String ?? "")
            }
            return (voices.filter { !$0.id.isEmpty }, data["has_more"] as? Bool ?? false)
        }
    }

    // MARK: - TTS

    func createTTSTask(voiceID: String, text: String, modelID: String, language: String,
                       provider: String, voiceSettings: [String: Any], exportTranscript: Bool) async throws -> String {
        var payload: [String: Any] = [
            "text": text,
            "language_code": language,
            "voice_settings": voiceSettings,
            "export_transcript": exportTranscript
        ]
        if provider != "capcut" { payload["model_id"] = modelID }
        if provider != "elevenlabs" { payload["provider"] = provider }

        let encodedID = voiceID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? voiceID
        let res = try await request("POST", "/v1/text-to-speech/\(encodedID)", body: payload, timeout: 60)
        guard let id = res["id"], "\(id)" != "" else {
            throw VibiError(message: "Phản hồi từ API không chứa Task ID!")
        }
        return "\(id)"
    }

    func waitForTask(_ taskID: String, timeoutSec: Double = 180, pollInterval: Double = 1.5) async throws -> [String: Any] {
        let start = Date()
        while Date().timeIntervalSince(start) < timeoutSec {
            try Task.checkCancellation()
            let task = try await request("GET", "/v1/history/\(taskID)", timeout: 15)
            let status = task["status"] as? String
            if status == "completed" { return task }
            if status == "failed" {
                let err = (task["error"] as? String) ?? "Lỗi xử lý tác vụ từ server Voice API"
                throw VibiError(message: "Tác vụ \(taskID) thất bại: \(err)")
            }
            try await Task.sleep(nanoseconds: UInt64(pollInterval * 1_000_000_000))
        }
        throw VibiError(message: "Quá thời gian chờ (\(Int(timeoutSec))s) cho tác vụ \(taskID)!")
    }

    func download(_ urlString: String) async throws -> Data {
        guard let url = URL(string: urlString) else { throw VibiError(message: "Link tải không hợp lệ.") }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            return data
        } catch {
            throw VibiError(message: "Lỗi tải file: \(error.localizedDescription)")
        }
    }

    // MARK: - Tiện ích

    static func splitLongText(_ text: String, maxChars: Int = 3500) -> [String] {
        if text.count <= maxChars { return [text] }
        let ns = text as NSString
        let re = try! NSRegularExpression(pattern: "(?<=[.!?\\n])\\s+")
        var sentences: [String] = []
        var last = 0
        for m in re.matches(in: text, range: NSRange(location: 0, length: ns.length)) {
            sentences.append(ns.substring(with: NSRange(location: last, length: m.range.location - last)))
            last = m.range.location + m.range.length
        }
        sentences.append(ns.substring(from: last))

        var chunks: [String] = []
        var cur = ""
        for s in sentences {
            if cur.count + s.count + 1 <= maxChars {
                cur += (cur.isEmpty ? "" : " ") + s
            } else {
                if !cur.isEmpty { chunks.append(cur.trimmingCharacters(in: .whitespacesAndNewlines)) }
                cur = s
            }
        }
        if !cur.isEmpty { chunks.append(cur.trimmingCharacters(in: .whitespacesAndNewlines)) }
        return chunks
    }

    /// Port từ tts_credits.py (tính bằng số nguyên để khỏi sai số thập phân).
    static func estimateCredits(text: String, provider: String, model: String) -> Int {
        let m = model.lowercased()
        let ratePercent: Int
        switch provider {
        case "elevenlabs": ratePercent = (m.contains("turbo") || m.contains("flash")) ? 50 : 100
        case "minimax": ratePercent = m.contains("turbo") ? 60 : 100
        case "capcut": ratePercent = 1
        default: ratePercent = 100
        }
        return (text.count * ratePercent + 99) / 100
    }
}
