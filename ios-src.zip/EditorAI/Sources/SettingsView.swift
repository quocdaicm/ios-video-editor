import SwiftUI

struct SettingsView: View {
    @AppStorage("vibi_api_key") private var apiKey = ""
    @AppStorage("vibi_api_base") private var apiBase = ""
    @State private var creditsText = "Số dư: -- credits"
    @State private var checking = false
    @State private var ok = true
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("Voice API Key (Vibi)") {
                    SecureField("Dán API Key vào đây", text: $apiKey)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Button {
                        Task { await check() }
                    } label: {
                        HStack {
                            if checking { ProgressView() }
                            Text("Kiểm tra số dư")
                        }
                    }
                    .disabled(apiKey.trimmingCharacters(in: .whitespaces).isEmpty || checking)
                    Text(creditsText)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(ok ? Color.green : Color.red)
                }

                Section("Nâng cao") {
                    TextField("https://api.vibi.pro", text: $apiBase)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    Text("Để trống để dùng địa chỉ mặc định.")
                        .font(.caption).foregroundStyle(.secondary)
                }

                Section {
                    Text("API Key được lưu trong bộ nhớ riêng của app trên máy bạn, không gửi đi đâu ngoài Vibi API.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Xong") { dismiss() } }
            }
        }
    }

    private func check() async {
        checking = true
        defer { checking = false }
        do {
            let c = try await VibiClient.shared.credits()
            ok = true
            creditsText = "Số dư: \(c) credits"
        } catch {
            ok = false
            creditsText = error.localizedDescription
        }
    }
}
