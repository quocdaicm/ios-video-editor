import SwiftUI

@main
struct EditorAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
