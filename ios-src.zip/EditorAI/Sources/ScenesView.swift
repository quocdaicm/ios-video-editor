import SwiftUI
import UniformTypeIdentifiers

private let sampleScenes = """
[
  {
    "id": "SC01",
    "character": "Người que",
    "character_info": "Người que 2D nét đen, nền trắng",
    "prompt": "Người que đứng trước cánh cổng lớn, phong cách 2D tối giản",
    "subtitle_ids": [1, 2],
    "start_at": "00:00:00,000",
    "end_at": "00:00:05,200",
    "motion": { "type": "zoom_in", "strength": "subtle" }
  },
  {
    "id": "SC02",
    "character": "Người que",
    "character_info": "Người que 2D nét đen, nền trắng",
    "prompt": "Người que bước vào khu rừng",
    "subtitle_ids": [3, 4],
    "start_at": "00:00:05,200",
    "end_at": "AUDIO_END"
  }
]
"""

struct ScenesView: View {
    @EnvironmentObject var projects: ProjectStore
    @State private var text = ""
    @State private var showImporter = false
    @State private var info: String?

    private var validation: (ok: Bool, message: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { return (false, "Chưa nhập nội dung JSON.") }
        do {
            let scenes = try SceneParser.parse(text: t)
            if scenes.isEmpty { return (false, "JSON hợp lệ nhưng chưa có phân cảnh.") }
            return (true, "✓ Đã nhận diện \(scenes.count) phân cảnh.")
        } catch {
            return (false, "JSON không hợp lệ: \(error.localizedDescription)")
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    Text(projects.active.map { "Dự án: \($0.meta.name)" } ?? "Chưa có dự án. Tạo ở tab Dự án để lưu kịch bản.")
                        .font(.subheadline)
                        .foregroundStyle(projects.active == nil ? Color.orange : Color.secondary)

                    Text("Nhập mảng JSON, mỗi phần tử là một cảnh với 7 trường bắt buộc (id, character, character_info, prompt, subtitle_ids, start_at, end_at). motion là tùy chọn.")
                        .font(.footnote).foregroundStyle(.secondary)

                    TextEditor(text: $text)
                        .font(.system(size: 13, design: .monospaced))
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                        .frame(minHeight: 280)
                        .padding(6)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 10))

                    Text(validation.message)
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(validation.ok ? Color.green : Color.red)

                    HStack {
                        Button { showImporter = true } label: { Label("Chọn file", systemImage: "doc") }
                        Button {
                            if let s = UIPasteboard.general.string { text = s }
                        } label: { Label("Dán", systemImage: "doc.on.clipboard") }
                        Button { text = sampleScenes } label: { Label("Mẫu", systemImage: "text.badge.plus") }
                    }
                    .buttonStyle(.bordered)
                    .font(.subheadline)

                    Button {
                        save()
                    } label: {
                        Label("Lưu vào dự án", systemImage: "square.and.arrow.down")
                            .fontWeight(.semibold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(validation.ok && projects.active != nil ? Color.blue : Color.gray)
                            .foregroundStyle(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    .disabled(!validation.ok || projects.active == nil)
                }
                .padding()
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("Kịch bản phân cảnh")
            .navigationBarTitleDisplayMode(.inline)
        }
        .onAppear {
            UITextView.appearance().smartQuotesType = .no
            UITextView.appearance().smartDashesType = .no
            loadFromProject()
        }
        .onChange(of: projects.activeSlug) { _ in loadFromProject() }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json, .plainText]) { result in
            if case .success(let url) = result {
                let ok = url.startAccessingSecurityScopedResource()
                defer { if ok { url.stopAccessingSecurityScopedResource() } }
                if let s = try? String(contentsOf: url, encoding: .utf8) { text = s }
                else { info = "Không đọc được file này." }
            }
        }
        .alert("Thông báo", isPresented: Binding(get: { info != nil }, set: { if !$0 { info = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(info ?? "")
        }
    }

    private func loadFromProject() {
        guard let p = projects.active else { text = ""; return }
        text = (try? String(contentsOf: p.scenesURL, encoding: .utf8)) ?? ""
    }

    private func save() {
        guard let p = projects.active, validation.ok else { return }
        do {
            try text.trimmingCharacters(in: .whitespacesAndNewlines)
                .write(to: p.scenesURL, atomically: true, encoding: .utf8)
            info = "Đã lưu kịch bản vào dự án «\(p.meta.name)»."
        } catch {
            info = "Không lưu được: \(error.localizedDescription)"
        }
    }
}
