import UIKit
import AVFoundation

final class CancelFlag {
    private let lock = NSLock()
    private var value = false
    var isCancelled: Bool { lock.lock(); defer { lock.unlock() }; return value }
    func cancel() { lock.lock(); value = true; lock.unlock() }
}

private final class ErrorBox {
    private let lock = NSLock()
    private var err: Error?
    func set(_ e: Error?) { lock.lock(); if err == nil { err = e }; lock.unlock() }
    var value: Error? { lock.lock(); defer { lock.unlock() }; return err }
}

/// Dựng video bằng AVFoundation: ảnh theo timeline + motion + (tùy chọn) phụ đề + audio -> MP4 H.264/AAC.
enum VideoRenderer {

    static func size(for aspect: String) -> (w: Int, h: Int) {
        switch aspect {
        case "9:16": return (1080, 1920)
        case "1:1": return (1080, 1080)
        default: return (1920, 1080)
        }
    }

    static func render(plan: RenderPlan, outputURL: URL, aspect: String, fps: Int,
                       burnSubtitles: Bool, cancel: CancelFlag,
                       progress: @escaping (Double) -> Void) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    try renderSync(plan: plan, outputURL: outputURL, aspect: aspect, fps: fps,
                                   burnSubtitles: burnSubtitles, cancel: cancel, progress: progress)
                    cont.resume()
                } catch {
                    cont.resume(throwing: error)
                }
            }
        }
    }

    // MARK: - Motion (port từ scene_motion.py)

    private static func motionRange(_ kind: String, _ strength: String) -> (Double, Double, Double, Double, Double, Double) {
        let subtle = strength == "subtle"
        switch kind {
        case "zoom_in": return (1, subtle ? 1.05 : 1.10, 0, 0, 0, 0)
        case "zoom_out": return (subtle ? 1.05 : 1.10, 1, 0, 0, 0, 0)
        case "pan_left", "pan_right", "pan_up", "pan_down":
            let d = subtle ? 0.03 : 0.06
            let scale = subtle ? 1.06 : 1.12
            let x = d * (kind == "pan_right" ? 1 : (kind == "pan_left" ? -1 : 0))
            let y = d * (kind == "pan_down" ? 1 : (kind == "pan_up" ? -1 : 0))
            return (scale, scale, 0, x, 0, y)
        case "drift_left", "drift_right":
            let (s0, s1, x0, x1): (Double, Double, Double, Double) =
                subtle ? (1.03, 1.06, 0.01, -0.02) : (1.04, 1.09, 0.02, -0.04)
            let dir: Double = kind == "drift_left" ? 1 : -1
            return (s0, s1, x0 * dir, x1 * dir, 0, 0)
        default: return (1, 1, 0, 0, 0, 0)
        }
    }

    /// Trả về (zoom, tx, ty) với tx, ty là phần trăm khung hình.
    private static func motionValues(kind: String, strength: String, progress: Double,
                                     frame: Int, fps: Int, w: Int, h: Int) -> (Double, Double, Double) {
        if kind == "shake" {
            let amp: Double = strength == "subtle" ? 2 : 4
            let env = pow(sin(Double.pi * progress), 2)
            let z = 1 + 2 * amp / Double(min(w, h))
            let tx = (amp / Double(w)) * env * sin(2 * Double.pi * 11 * Double(frame) / Double(fps))
            let ty = (amp / Double(h)) * env * cos(2 * Double.pi * 13 * Double(frame) / Double(fps))
            return (z, tx, ty)
        }
        let (s0, s1, x0, x1, y0, y1) = motionRange(kind, strength)
        let eased = (1 - cos(Double.pi * progress)) / 2
        return (s0 + (s1 - s0) * eased, x0 + (x1 - x0) * eased, y0 + (y1 - y0) * eased)
    }

    // MARK: - Vẽ

    private static func coverImage(url: URL, w: Int, h: Int) -> UIImage? {
        guard let img = UIImage(contentsOfFile: url.path), img.size.width > 0, img.size.height > 0 else { return nil }
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = true
        let r = UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: fmt)
        return r.image { _ in
            let s = max(CGFloat(w) / img.size.width, CGFloat(h) / img.size.height)
            let iw = img.size.width * s
            let ih = img.size.height * s
            img.draw(in: CGRect(x: (CGFloat(w) - iw) / 2, y: (CGFloat(h) - ih) / 2, width: iw, height: ih))
        }
    }

    private static func drawSubtitle(_ text: String, w: Int, h: Int) {
        let fontSize = max(18, (Double(h) * 0.039).rounded())
        let margin = max(12, (Double(h) * 0.035).rounded())
        let pad = fontSize * 0.3
        let para = NSMutableParagraphStyle()
        para.alignment = .center
        para.lineBreakMode = .byWordWrapping
        let attrs: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: CGFloat(fontSize)),
            .foregroundColor: UIColor.white,
            .paragraphStyle: para
        ]
        let maxW = CGFloat(Double(w) - 2 * margin - 2 * pad)
        let bounds = (text as NSString).boundingRect(
            with: CGSize(width: maxW, height: .greatestFiniteMagnitude),
            options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attrs, context: nil)
        let tw = ceil(bounds.width)
        let th = ceil(bounds.height)
        let box = CGRect(x: (CGFloat(w) - tw) / 2 - CGFloat(pad),
                         y: CGFloat(Double(h) - margin) - th - CGFloat(2 * pad),
                         width: tw + CGFloat(2 * pad), height: th + CGFloat(2 * pad))
        UIColor(red: 15 / 255, green: 8 / 255, blue: 5 / 255, alpha: 0.75).setFill()
        UIBezierPath(roundedRect: box, cornerRadius: 6).fill()
        (text as NSString).draw(in: CGRect(x: box.minX + CGFloat(pad), y: box.minY + CGFloat(pad), width: tw, height: th),
                                withAttributes: attrs)
    }

    // MARK: - Ghi file

    private static func renderSync(plan: RenderPlan, outputURL: URL, aspect: String, fps: Int,
                                   burnSubtitles: Bool, cancel: CancelFlag,
                                   progress: @escaping (Double) -> Void) throws {
        let (W, H) = size(for: aspect)
        let timeline = plan.timeline
        guard !timeline.isEmpty else { throw RenderError("Timeline trống.") }
        let totalFrames = max(1, Int((plan.totalDuration * Double(fps)).rounded()))
        let endFrames = timeline.map { Int(($0.end * Double(fps)).rounded()) }
        let startFrames = timeline.map { Int(($0.start * Double(fps)).rounded()) }
        let cueList = plan.cues.values.sorted { $0.id < $1.id }

        try? FileManager.default.removeItem(at: outputURL)
        try FileManager.default.createDirectory(at: outputURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mp4)

        let vSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: W,
            AVVideoHeightKey: H,
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: W * H * 4,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
                AVVideoMaxKeyFrameIntervalKey: fps * 2
            ] as [String: Any]
        ]
        let vIn = AVAssetWriterInput(mediaType: .video, outputSettings: vSettings)
        vIn.expectsMediaDataInRealTime = false
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: vIn,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: W,
                kCVPixelBufferHeightKey as String: H
            ])
        guard writer.canAdd(vIn) else { throw RenderError("Không thêm được luồng video.") }
        writer.add(vIn)

        // Âm thanh: giải mã MP3 -> PCM -> mã hóa AAC
        let asset = AVURLAsset(url: plan.audio)
        guard let track = asset.tracks(withMediaType: .audio).first else {
            throw RenderError("File giọng đọc không có luồng âm thanh.")
        }
        var rate = 44100.0
        var channels = 2
        if let fd = (track.formatDescriptions as? [CMFormatDescription])?.first,
           let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(fd)?.pointee {
            if asbd.mSampleRate > 0 { rate = asbd.mSampleRate }
            if asbd.mChannelsPerFrame > 0 { channels = min(2, Int(asbd.mChannelsPerFrame)) }
        }
        let reader = try AVAssetReader(asset: asset)
        let aOut = AVAssetReaderTrackOutput(track: track, outputSettings: [
            AVFormatIDKey: kAudioFormatLinearPCM,
            AVLinearPCMBitDepthKey: 16,
            AVLinearPCMIsFloatKey: false,
            AVLinearPCMIsBigEndianKey: false,
            AVLinearPCMIsNonInterleaved: false,
            AVSampleRateKey: rate,
            AVNumberOfChannelsKey: channels
        ])
        guard reader.canAdd(aOut) else { throw RenderError("Không đọc được âm thanh.") }
        reader.add(aOut)
        let aIn = AVAssetWriterInput(mediaType: .audio, outputSettings: [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: rate,
            AVNumberOfChannelsKey: channels,
            AVEncoderBitRateKey: 128_000
        ])
        aIn.expectsMediaDataInRealTime = false
        guard writer.canAdd(aIn) else { throw RenderError("Không thêm được luồng âm thanh.") }
        writer.add(aIn)

        guard writer.startWriting() else {
            throw RenderError("Không bắt đầu ghi được file: \(writer.error?.localizedDescription ?? "không rõ lỗi")")
        }
        guard reader.startReading() else {
            throw RenderError("Không bắt đầu đọc âm thanh: \(reader.error?.localizedDescription ?? "không rõ lỗi")")
        }
        writer.startSession(atSourceTime: .zero)

        let group = DispatchGroup()
        let errors = ErrorBox()
        let vQueue = DispatchQueue(label: "editorai.video")
        let aQueue = DispatchQueue(label: "editorai.audio")

        var frameIndex = 0
        var sceneIdx = 0
        var loadedScene = -1
        var cover: UIImage?

        group.enter()
        vIn.requestMediaDataWhenReady(on: vQueue) {
            while vIn.isReadyForMoreMediaData {
                if cancel.isCancelled || frameIndex >= totalFrames {
                    vIn.markAsFinished()
                    group.leave()
                    return
                }
                guard let pool = adaptor.pixelBufferPool else {
                    errors.set(RenderError("Không tạo được bộ đệm khung hình."))
                    vIn.markAsFinished(); group.leave(); return
                }
                var ok = true
                autoreleasepool {
                    while sceneIdx < timeline.count - 1 && frameIndex >= endFrames[sceneIdx] { sceneIdx += 1 }
                    if loadedScene != sceneIdx {
                        cover = coverImage(url: timeline[sceneIdx].image, w: W, h: H)
                        loadedScene = sceneIdx
                    }
                    var pbOpt: CVPixelBuffer?
                    CVPixelBufferPoolCreatePixelBuffer(nil, pool, &pbOpt)
                    guard let pb = pbOpt else { ok = false; return }
                    CVPixelBufferLockBaseAddress(pb, [])
                    defer { CVPixelBufferUnlockBaseAddress(pb, []) }
                    guard let ctx = CGContext(
                        data: CVPixelBufferGetBaseAddress(pb), width: W, height: H, bitsPerComponent: 8,
                        bytesPerRow: CVPixelBufferGetBytesPerRow(pb),
                        space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
                        bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
                    ) else { ok = false; return }

                    ctx.translateBy(x: 0, y: CGFloat(H))
                    ctx.scaleBy(x: 1, y: -1)
                    ctx.interpolationQuality = .high
                    UIGraphicsPushContext(ctx)
                    UIColor.black.setFill()
                    ctx.fill(CGRect(x: 0, y: 0, width: W, height: H))

                    if let img = cover {
                        let item = timeline[sceneIdx]
                        let local = frameIndex - startFrames[sceneIdx]
                        let sceneFrames = max(1, endFrames[sceneIdx] - startFrames[sceneIdx])
                        let p = min(1, max(0, Double(local) / Double(max(1, sceneFrames - 1))))
                        let (z, tx, ty) = motionValues(kind: item.motionType, strength: item.motionStrength,
                                                       progress: p, frame: local, fps: fps, w: W, h: H)
                        let fw = Double(W), fh = Double(H)
                        let x = max(0, min(fw - fw / z, (fw - fw / z) / 2 - tx * fw / z))
                        let y = max(0, min(fh - fh / z, (fh - fh / z) / 2 - ty * fh / z))
                        img.draw(in: CGRect(x: -x * z, y: -y * z, width: fw * z, height: fh * z))
                    }

                    if burnSubtitles {
                        let t = (Double(frameIndex) + 0.5) / Double(fps)
                        let active = cueList.filter { $0.start <= t && t < $0.end && !$0.text.isEmpty }
                        if !active.isEmpty {
                            drawSubtitle(active.map { $0.text }.joined(separator: "\n"), w: W, h: H)
                        }
                    }
                    UIGraphicsPopContext()

                    let time = CMTime(value: CMTimeValue(frameIndex), timescale: CMTimeScale(fps))
                    ok = adaptor.append(pb, withPresentationTime: time)
                }
                if !ok {
                    errors.set(writer.error ?? RenderError("Ghi khung hình thất bại."))
                    vIn.markAsFinished(); group.leave(); return
                }
                frameIndex += 1
                if frameIndex % 10 == 0 { progress(Double(frameIndex) / Double(totalFrames)) }
            }
        }

        group.enter()
        aIn.requestMediaDataWhenReady(on: aQueue) {
            while aIn.isReadyForMoreMediaData {
                if cancel.isCancelled {
                    aIn.markAsFinished(); group.leave(); return
                }
                if let sb = aOut.copyNextSampleBuffer() {
                    if !aIn.append(sb) {
                        errors.set(writer.error ?? RenderError("Ghi âm thanh thất bại."))
                        aIn.markAsFinished(); group.leave(); return
                    }
                } else {
                    aIn.markAsFinished(); group.leave(); return
                }
            }
        }

        group.wait()

        if cancel.isCancelled {
            reader.cancelReading()
            writer.cancelWriting()
            try? FileManager.default.removeItem(at: outputURL)
            throw CancellationError()
        }
        if let e = errors.value {
            reader.cancelReading()
            writer.cancelWriting()
            try? FileManager.default.removeItem(at: outputURL)
            throw e
        }
        let sem = DispatchSemaphore(value: 0)
        writer.finishWriting { sem.signal() }
        sem.wait()
        guard writer.status == .completed else {
            throw RenderError("Xuất video thất bại: \(writer.error?.localizedDescription ?? "không rõ lỗi")")
        }
        progress(1.0)
    }
}
