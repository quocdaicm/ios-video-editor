import UIKit

enum PresetMode: String, CaseIterable, Identifiable {
    case auto = "Tự động"
    case classic = "Classic"
    var id: String { rawValue }
}

private struct Preset {
    var offsetX: Int
    var offsetY: Int
    var sizeScale: Double
}

/// Python round() làm tròn về số chẵn gần nhất, giữ đúng như bản desktop.
private func pyRound(_ v: Double) -> Int {
    Int(v.rounded(.toNearestOrEven))
}

/// Port từ app/core/watermark_remover.py (bản desktop).
final class GeminiWatermarkRemover {
    static let shared = GeminiWatermarkRemover()

    private let bg48: CGImage?
    private let bg96: CGImage?

    private init() {
        bg48 = GeminiWatermarkRemover.loadTemplate("bg_48")
        bg96 = GeminiWatermarkRemover.loadTemplate("bg_96")
    }

    private static func loadTemplate(_ name: String) -> CGImage? {
        guard let url = Bundle.main.url(forResource: name, withExtension: "png"),
              let data = try? Data(contentsOf: url),
              let img = UIImage(data: data)?.cgImage else { return nil }
        return img
    }

    // MARK: - Hình học

    private func baseInfo(w: Int, h: Int) -> (size: Int, x: Int, y: Int) {
        let a = Double(min(w, h)) / 1536.0
        let size = max(16, pyRound(96 * a))
        let margin = max(8, pyRound(64 * a))
        return (size, max(0, w - margin - size), max(0, h - margin - size))
    }

    private func adaptivePreset(mode: PresetMode, w: Int, h: Int) -> Preset {
        if mode == .classic {
            return Preset(offsetX: 0, offsetY: 0, sizeScale: 1.0)
        }
        let minDim = min(w, h)
        let maxDim = max(w, h)
        let ratio = Double(maxDim) / Double(max(1, minDim))
        let scale: Double
        let offset: Int
        if minDim >= 1800 || maxDim >= 2400 {
            if ratio >= 1.65 { scale = 0.5; offset = -1 }
            else if ratio >= 1.42 { scale = 0.46; offset = 6 }
            else if ratio >= 1.18 { scale = 0.43; offset = 13 }
            else { scale = 0.38; offset = 25 }
        } else {
            if ratio >= 1.65 { scale = 1.01; offset = -41 }
            else if ratio >= 1.42 { scale = 0.92; offset = -38 }
            else if ratio >= 1.18 { scale = 0.86; offset = -35 }
            else { scale = 0.75; offset = -27 }
        }
        return Preset(offsetX: offset, offsetY: offset, sizeScale: scale)
    }

    private func resolveBox(base: (size: Int, x: Int, y: Int), w: Int, h: Int, preset: Preset) -> (size: Int, x: Int, y: Int) {
        let size = max(8, min(pyRound(Double(base.size) * preset.sizeScale), min(w, h)))
        let cx = Double(base.x) + Double(base.size) / 2.0 + Double(preset.offsetX)
        let cy = Double(base.y) + Double(base.size) / 2.0 + Double(preset.offsetY)
        let x = max(0, min(pyRound(cx - Double(size) / 2.0), w - size))
        let y = max(0, min(pyRound(cy - Double(size) / 2.0), h - size))
        return (size, x, y)
    }

    // MARK: - Pixel helpers

    private func makeContext(width: Int, height: Int) -> CGContext? {
        CGContext(
            data: nil,
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: width * 4,
            space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue
        )
    }

    /// Vẽ lại ảnh theo đúng chiều (xử lý EXIF orientation), nền đặc.
    private func upright(_ image: UIImage) -> CGImage? {
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = true
        let renderer = UIGraphicsImageRenderer(size: image.size, format: fmt)
        let redrawn = renderer.image { _ in
            image.draw(in: CGRect(origin: .zero, size: image.size))
        }
        return redrawn.cgImage
    }

    // MARK: - Gỡ watermark

    func removeWatermark(from image: UIImage, gain: Double = 0.6, mode: PresetMode = .auto) -> UIImage? {
        guard let src = upright(image) else { return nil }
        let w = src.width
        let h = src.height
        guard w > 0, h > 0,
              let ctx = makeContext(width: w, height: h) else { return nil }
        ctx.interpolationQuality = .high
        ctx.draw(src, in: CGRect(x: 0, y: 0, width: w, height: h))
        guard let raw = ctx.data else { return nil }
        let px = raw.bindMemory(to: UInt8.self, capacity: w * h * 4)

        let base = baseInfo(w: w, h: h)
        let preset = adaptivePreset(mode: mode, w: w, h: h)
        let box = resolveBox(base: base, w: w, h: h, preset: preset)
        let bw = box.size
        let bh = box.size

        guard let tplImg = (bw <= 48 ? bg48 : bg96),
              let tctx = makeContext(width: bw, height: bh) else { return nil }
        tctx.interpolationQuality = .high
        tctx.draw(tplImg, in: CGRect(x: 0, y: 0, width: bw, height: bh))
        guard let traw = tctx.data else { return nil }
        let tp = traw.bindMemory(to: UInt8.self, capacity: bw * bh * 4)

        for j in 0..<bh {
            for i in 0..<bw {
                let ti = (j * bw + i) * 4
                let rgbMax = Double(max(tp[ti], max(tp[ti + 1], tp[ti + 2])))
                let alpha = (rgbMax / 255.0) * gain
                if alpha < 0.002 { continue }

                let ac = min(max(alpha, 0.0), 0.99)
                let eff: Double
                if ac < 0.2 {
                    let t = ac / 0.2
                    eff = t * t * (3.0 - 2.0 * t) * ac
                } else {
                    eff = ac
                }
                let inv = 1.0 / (1.0 - eff)
                let logo = 255.0 * eff

                let idx = ((box.y + j) * w + (box.x + i)) * 4
                for c in 0..<3 {
                    let v = (Double(px[idx + c]) - logo) * inv
                    px[idx + c] = UInt8(min(max(v + 0.5, 0.0), 255.0))
                }
            }
        }

        guard let out = ctx.makeImage() else { return nil }
        return UIImage(cgImage: out)
    }
}
