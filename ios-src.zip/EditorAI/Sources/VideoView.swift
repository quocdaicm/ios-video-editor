import SwiftUI
import AVKit
import Photos
import ImageIO

private func thumbnail(_ url: URL, maxPixel: Int = 160) -> UIImage? {
    guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
    let opts: [CFString: Any] = [
        kCGImageSourceCreateThumbnailFromImageAlways: true,
        kCGImageSourceCreateThumbnailWithTransform: true,
        kCGImageSourceThumbnailMaxPixelSize: maxPixel
    ]
    guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
    return UIImage(cgImage: cg)
}

private func clock(_ t: Double) -> String {
    let m = Int(t) / 60
    let s = t - Double(m * 60)
    return String(format: "%d:%04.1f", m, s)
}

@MainActor
final class VideoViewModel: ObservableObject {
    @Published var plan: RenderPlan?
    @Published var planError: String?
    @Published var isRendering = false
    @Published var progress = 0.0
    @Published var outputURL: URL?
    @Published var errorText: String?
    @Published var message: String?

    private var cancelFlag = CancelFlag()
    private var task: Task<Void, Never>?

    func refresh(_ project: Project?) async {
        guard let project = project else { plan = nil; planError = "Chưa có dự án. Tạo ở tab Dự án."; return }
        do {
            plan = try await VideoPlanner.build(project: project)
            planError = nil
        } catch {
            plan = nil
            planError = error.localizedDescription
        }
    }

    func export(project: Project, aspect: String, fps: Int, burnSubtitles: Bool) {
        task?.cancel()
        task = Task { await runExport(project: project, aspect: aspect, fps: fps, burn: burnSubtitles) }
    }

    func cancel() { cancelFlag.cancel() }

    private func runExport(project: Project, aspect: String, fps: Int, burn: Bool) async {
        isRendering = true
        progress = 0
        errorText = nil
        outputURL = nil
        UIApplication.shared.isIdleTimerDisabled = true
        defer {
            isRendering = false
            UIApplication.shared.isIdleTimerDisabled = false
        }
        do {
            let fresh = try await VideoPlanner.build(project: project)
            plan = fresh
            planError = nil
            let f = DateFormatter()
            f.dateFormat = "yyyyMMdd_HHmmss"
            let url = project.outputDir.appendingPathComponent("video_\(f.string(from: Date())).mp4")
            let flag = CancelFlag()
            cancelFlag = flag
            try await VideoRenderer.render(plan: fresh, outputURL: url, aspect: aspect, fps: fps,
                                           burnSubtitles: burn, cancel: flag) { [weak self] p in
                Task { @MainActor in self?.progress = p }
            }
            outputURL = url
        } catch is CancellationError {
            errorText = "Đã hủy."
        } catch {
            errorText = error.localizedDescription
        }
    }

    func saveToPhotos() async {
        guard let url = outputURL else { return }
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else {
            message = "Chưa cấp quyền lưu ảnh. Vào Cài đặt > Editor AI > Ảnh để bật."
            return
        }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetCreationRequest.creationRequestForAssetFromVideo(atFileURL: url)
            }
            message = "Đã lưu video vào thư viện Ảnh."
        } catch {
            message = "Không lưu được: \(error.localizedDescription)"
        }
    }
}

struct VideoPreview: View {
    let url: URL
    @State private var player: AVPlayer?

    var body: some View {
        Group {
            if let player = player {
                VideoPlayer(player: player)
            } else {
                Color.black
            }
        }
        .onAppear { player = AVPlayer(url: url) }
        .onChange(of: url) { newURL in player = AVPlayer(url: newURL) }
        .onDisappear { player?.pause() }
    }
}

struct VideoView: View {
    @EnvironmentObject var projects: ProjectStore
    @StateObject private var vm = VideoViewModel()
    @State private var aspect = "16:9"
    @State private var fps = 30
    @State private var burnSubtitles = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {
                    header
                    settingsCard
                    timelineCard
                    exportButton
                    if let err = vm.errorText {
                        Text(err).font(.footnote).foregroundStyle(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    if let url = vm.outputURL { resultCard(url) }
                }
                .padding()
            }
            .navigationTitle("Dựng video")
            .navigationBarTitleDisplayMode(.inline)
        }
        .onAppear { syncFromProject(); Task { await vm.refresh(projects.active) } }
        .onChange(of: projects.activeSlug) { _ in
            vm.outputURL = nil
            syncFromProject()
            Task { await vm.refresh(projects.active) }
        }
        .alert("Thông báo", isPresented: Binding(get: { vm.message != nil }, set: { if !$0 { vm.message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(vm.message ?? "")
        }
    }

    private func syncFromProject() {
        if let p = projects.active {
            aspect = p.meta.aspect
            fps = p.meta.fps
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(projects.active.map { "Dự án: \($0.meta.name)" } ?? "Chưa có dự án. Tạo ở tab Dự án.")
                .font(.subheadline)
                .foregroundStyle(projects.active == nil ? Color.orange : Color.secondary)
            Text("Cần đủ: ảnh sạch SCxx_clean.png, giọng đọc (MP3), kịch bản. Phụ đề SRT dùng cho cảnh chia theo subtitle_ids.")
                .font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var settingsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("Tỉ lệ", selection: $aspect) {
                Text("16:9").tag("16:9")
                Text("9:16").tag("9:16")
                Text("1:1").tag("1:1")
            }
            .pickerStyle(.segmented)
            Picker("FPS", selection: $fps) {
                ForEach([24, 25, 30, 60], id: \.self) { Text("\($0) FPS").tag($0) }
            }
            .pickerStyle(.segmented)
            Toggle("Ghi phụ đề lên video", isOn: $burnSubtitles)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private var timelineCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Timeline").font(.headline)
                Spacer()
                Button {
                    Task { await vm.refresh(projects.active) }
                } label: { Label("Làm mới", systemImage: "arrow.clockwise").font(.subheadline) }
            }
            if let err = vm.planError {
                Text(err).font(.footnote).foregroundStyle(.red)
            } else if let plan = vm.plan {
                Text("\(plan.timeline.count) cảnh · \(clock(plan.totalDuration))")
                    .font(.caption).foregroundStyle(.secondary)
                ForEach(plan.timeline) { item in
                    HStack(spacing: 10) {
                        if let ui = thumbnail(item.image) {
                            Image(uiImage: ui)
                                .resizable().scaledToFill()
                                .frame(width: 64, height: 40)
                                .clipShape(RoundedRectangle(cornerRadius: 6))
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text(item.id).font(.subheadline.weight(.semibold))
                            Text("\(clock(item.start)) → \(clock(item.end)) · \(item.motionType) (\(item.motionStrength))")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                }
            } else {
                ProgressView()
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private var canExport: Bool { vm.plan != nil && !vm.isRendering && projects.active != nil }

    private var exportButton: some View {
        VStack(spacing: 8) {
            HStack(spacing: 10) {
                Button {
                    if let p = projects.active {
                        vm.export(project: p, aspect: aspect, fps: fps, burnSubtitles: burnSubtitles)
                    }
                } label: {
                    HStack {
                        if vm.isRendering { ProgressView().tint(.white) }
                        Text(vm.isRendering ? "Đang xuất \(Int(vm.progress * 100))%" : "Xuất video MP4")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(canExport ? Color.blue : Color.gray)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .disabled(!canExport)

                if vm.isRendering {
                    Button("Hủy") { vm.cancel() }.buttonStyle(.bordered).tint(.red)
                }
            }
            if vm.isRendering {
                ProgressView(value: vm.progress)
                Text("Giữ màn hình sáng và để app ở phía trước cho đến khi xuất xong.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private func resultCard(_ url: URL) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Kết quả").font(.headline)
            VideoPreview(url: url)
                .aspectRatio(aspect == "9:16" ? 9.0 / 16.0 : (aspect == "1:1" ? 1.0 : 16.0 / 9.0), contentMode: .fit)
                .frame(maxHeight: 420)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            HStack {
                ShareLink(item: url) { Label("Chia sẻ", systemImage: "square.and.arrow.up") }
                Spacer()
                Button {
                    Task { await vm.saveToPhotos() }
                } label: { Label("Lưu vào Ảnh", systemImage: "square.and.arrow.down") }
            }
            .font(.subheadline)
            Text("Video cũng nằm trong Tệp > Editor AI > Projects > \(projects.activeSlug) > output.")
                .font(.caption).foregroundStyle(.secondary)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
