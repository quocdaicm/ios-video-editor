import SwiftUI
import PhotosUI

struct ResultItem: Identifiable {
    let id = UUID()
    let name: String
    let original: UIImage
    let cleaned: UIImage
}

@MainActor
final class WatermarkViewModel: ObservableObject {
    @Published var pickerItems: [PhotosPickerItem] = []
    @Published var results: [ResultItem] = []
    @Published var gain: Double = 0.6
    @Published var mode: PresetMode = .auto
    @Published var isProcessing = false
    @Published var progress = ""
    @Published var message: String?

    func process() async {
        guard !pickerItems.isEmpty else { return }
        isProcessing = true
        results = []
        let g = gain
        let m = mode
        let total = pickerItems.count
        var done = 0

        for (index, item) in pickerItems.enumerated() {
            progress = "Đang xử lý \(index + 1)/\(total)..."
            guard let data = try? await item.loadTransferable(type: Data.self),
                  let ui = UIImage(data: data) else { continue }
            let cleaned = await Task.detached(priority: .userInitiated) {
                GeminiWatermarkRemover.shared.removeWatermark(from: ui, gain: g, mode: m)
            }.value
            if let cleaned = cleaned {
                results.append(ResultItem(name: "anh_sach_\(index + 1)", original: ui, cleaned: cleaned))
                done += 1
            }
        }

        isProcessing = false
        progress = ""
        message = done == total
            ? "Đã xử lý xong \(done) ảnh."
            : "Xử lý được \(done)/\(total) ảnh. Một số ảnh không đọc được."
    }

    func saveToProject(_ project: Project, startScene: Int) {
        var saved = 0
        for (i, r) in results.enumerated() {
            guard let data = r.cleaned.pngData() else { continue }
            let url = project.cleanDir.appendingPathComponent(String(format: "SC%02d_clean.png", startScene + i))
            if (try? data.write(to: url)) != nil { saved += 1 }
        }
        message = "Đã lưu \(saved) ảnh vào dự án «\(project.meta.name)» (images/clean)."
    }

    func saveAllToPhotos() async {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else {
            message = "Chưa cấp quyền lưu ảnh. Vào Cài đặt > Editor AI > Ảnh để bật."
            return
        }
        var saved = 0
        for r in results {
            guard let data = r.cleaned.pngData() else { continue }
            do {
                try await PHPhotoLibrary.shared().performChanges {
                    let req = PHAssetCreationRequest.forAsset()
                    req.addResource(with: .photo, data: data, options: nil)
                }
                saved += 1
            } catch {
                continue
            }
        }
        message = "Đã lưu \(saved) ảnh vào thư viện Ảnh."
    }
}
