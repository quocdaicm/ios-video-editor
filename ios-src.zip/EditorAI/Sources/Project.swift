import Foundation

enum ProjectPaths {
    static var root: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let url = docs.appendingPathComponent("Projects", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }
}

struct ProjectMeta: Codable {
    var name: String
    var aspect: String   // "16:9", "9:16", "1:1"
    var fps: Int
    var created: String
}

private let imageExts: Set<String> = ["jpg", "jpeg", "png", "webp", "bmp"]
private let audioExts: Set<String> = ["mp3", "wav", "m4a", "aac", "ogg"]

/// Cấu trúc giống bản desktop:
/// project.json, scenes.json, images/clean, voice, output
struct Project: Identifiable {
    let slug: String
    var meta: ProjectMeta
    var id: String { slug }

    var dir: URL { ProjectPaths.root.appendingPathComponent(slug, isDirectory: true) }
    var scenesURL: URL { dir.appendingPathComponent("scenes.json") }
    var metaURL: URL { dir.appendingPathComponent("project.json") }

    private func ensured(_ url: URL) -> URL {
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }
    var cleanDir: URL { ensured(dir.appendingPathComponent("images/clean", isDirectory: true)) }
    var voiceDir: URL { ensured(dir.appendingPathComponent("voice", isDirectory: true)) }
    var outputDir: URL { ensured(dir.appendingPathComponent("output", isDirectory: true)) }

    private func files(in folder: URL, exts: Set<String>) -> [URL] {
        let items = (try? FileManager.default.contentsOfDirectory(
            at: folder, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        return items.filter { exts.contains($0.pathExtension.lowercased()) }
    }

    var cleanImages: [URL] {
        files(in: cleanDir, exts: imageExts).sorted { $0.lastPathComponent < $1.lastPathComponent }
    }

    private func newest(_ list: [URL]) -> URL? {
        list.max { a, b in
            let da = (try? a.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
            let db = (try? b.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
            return da < db
        }
    }
    var latestVoice: URL? { newest(files(in: voiceDir, exts: audioExts)) }
    var latestSRT: URL? { newest(files(in: voiceDir, exts: ["srt"])) }

    var sceneCount: Int {
        guard let s = try? String(contentsOf: scenesURL, encoding: .utf8) else { return 0 }
        return (try? SceneParser.parse(text: s).count) ?? 0
    }

    var aspectSize: (width: Int, height: Int) {
        switch meta.aspect {
        case "9:16": return (1080, 1920)
        case "1:1": return (1080, 1080)
        default: return (1920, 1080)
        }
    }
}

@MainActor
final class ProjectStore: ObservableObject {
    @Published var projects: [Project] = []
    @Published var activeSlug: String {
        didSet { UserDefaults.standard.set(activeSlug, forKey: "active_project") }
    }

    var active: Project? { projects.first { $0.slug == activeSlug } }

    init() {
        activeSlug = UserDefaults.standard.string(forKey: "active_project") ?? ""
        reload()
        if active == nil { activeSlug = projects.first?.slug ?? "" }
    }

    func reload() {
        let dirs = (try? FileManager.default.contentsOfDirectory(
            at: ProjectPaths.root, includingPropertiesForKeys: nil)) ?? []
        var list: [Project] = []
        for d in dirs {
            let metaURL = d.appendingPathComponent("project.json")
            if let data = try? Data(contentsOf: metaURL),
               let meta = try? JSONDecoder().decode(ProjectMeta.self, from: data) {
                list.append(Project(slug: d.lastPathComponent, meta: meta))
            }
        }
        projects = list.sorted { $0.meta.created > $1.meta.created }
    }

    static func slugify(_ text: String) -> String {
        var s = text.replacingOccurrences(of: "đ", with: "d").replacingOccurrences(of: "Đ", with: "D")
        s = s.folding(options: .diacriticInsensitive, locale: Locale(identifier: "en"))
        s = s.replacingOccurrences(of: "[^a-zA-Z0-9_-]+", with: "_", options: .regularExpression)
        s = s.replacingOccurrences(of: "_+", with: "_", options: .regularExpression)
        s = s.trimmingCharacters(in: CharacterSet(charactersIn: "_"))
        if s.isEmpty {
            let f = DateFormatter(); f.dateFormat = "yyyyMMdd_HHmmss"
            return "project_" + f.string(from: Date())
        }
        return s
    }

    @discardableResult
    func create(name: String, aspect: String, fps: Int) throws -> Project {
        let base = Self.slugify(name)
        var slug = base
        var n = 2
        while FileManager.default.fileExists(atPath: ProjectPaths.root.appendingPathComponent(slug).path) {
            slug = "\(base)_\(n)"; n += 1
        }
        let iso = ISO8601DateFormatter().string(from: Date())
        let meta = ProjectMeta(name: name.trimmingCharacters(in: .whitespaces), aspect: aspect, fps: fps, created: iso)
        let project = Project(slug: slug, meta: meta)
        try FileManager.default.createDirectory(at: project.dir, withIntermediateDirectories: true)
        _ = project.cleanDir; _ = project.voiceDir; _ = project.outputDir
        let enc = JSONEncoder()
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        try enc.encode(meta).write(to: project.metaURL)
        reload()
        activeSlug = slug
        return project
    }

    func delete(_ p: Project) {
        try? FileManager.default.removeItem(at: p.dir)
        reload()
        if activeSlug == p.slug { activeSlug = projects.first?.slug ?? "" }
    }
}
