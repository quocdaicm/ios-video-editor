import SwiftUI

struct ContentView: View {
    @StateObject private var projects = ProjectStore()

    var body: some View {
        TabView {
            ProjectsView()
                .tabItem { Label("Dự án", systemImage: "folder") }
            WatermarkView()
                .tabItem { Label("Watermark", systemImage: "wand.and.stars") }
            TTSView()
                .tabItem { Label("Giọng TTS", systemImage: "waveform") }
            ScenesView()
                .tabItem { Label("Kịch bản", systemImage: "list.bullet.rectangle") }
            VideoView()
                .tabItem { Label("Video", systemImage: "film") }
        }
        .environmentObject(projects)
    }
}
