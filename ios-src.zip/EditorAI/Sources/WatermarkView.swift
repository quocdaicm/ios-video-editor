import SwiftUI
import PhotosUI

struct WatermarkView: View {
    @StateObject private var vm = WatermarkViewModel()
    @EnvironmentObject var projects: ProjectStore
    @State private var startScene = 1

    @ViewBuilder
    private var projectSaveCard: some View {
        if let p = projects.active {
            VStack(alignment: .leading, spacing: 8) {
                Stepper("Bắt đầu từ cảnh số \(startScene)", value: $startScene, in: 1...99)
                    .font(.subheadline)
                Text("Ảnh lưu thành SC\(String(format: "%02d", startScene))_clean.png, SC\(String(format: "%02d", startScene + 1))_clean.png...")
                    .font(.caption).foregroundStyle(.secondary)
                Button {
                    vm.saveToProject(p, startScene: startScene)
                } label: {
                    Label("Lưu vào dự án «\(p.meta.name)»", systemImage: "tray.and.arrow.down")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange.opacity(0.18))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
            }
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    PhotosPicker(selection: $vm.pickerItems, maxSelectionCount: 20, matching: .images) {
                        Label("Chọn ảnh (\(vm.pickerItems.count))", systemImage: "photo.on.rectangle")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue.opacity(0.12))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Chế độ").font(.subheadline).foregroundStyle(.secondary)
                        Picker("Chế độ", selection: $vm.mode) {
                            ForEach(PresetMode.allCases) { m in
                                Text(m.rawValue).tag(m)
                            }
                        }
                        .pickerStyle(.segmented)

                        Text("Độ mạnh (gain): \(vm.gain, specifier: "%.2f")")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Slider(value: $vm.gain, in: 0.3...1.0, step: 0.05)
                    }
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 12))

                    Button {
                        Task { await vm.process() }
                    } label: {
                        HStack {
                            if vm.isProcessing { ProgressView().tint(.white) }
                            Text(vm.isProcessing ? vm.progress : "Gỡ watermark")
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(vm.pickerItems.isEmpty || vm.isProcessing ? Color.gray : Color.blue)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    .disabled(vm.pickerItems.isEmpty || vm.isProcessing)

                    if !vm.results.isEmpty {
                        Button {
                            Task { await vm.saveAllToPhotos() }
                        } label: {
                            Label("Lưu tất cả vào Ảnh", systemImage: "square.and.arrow.down")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.green.opacity(0.15))
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                        }

                        projectSaveCard

                        ForEach(vm.results) { item in
                            ResultRow(item: item)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Gỡ watermark ảnh")
            .navigationBarTitleDisplayMode(.inline)
        }
        .alert("Thông báo", isPresented: Binding(
            get: { vm.message != nil },
            set: { if !$0 { vm.message = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(vm.message ?? "")
        }
    }
}

struct ResultRow: View {
    let item: ResultItem
    @State private var showOriginal = false

    var body: some View {
        VStack(spacing: 8) {
            Image(uiImage: showOriginal ? item.original : item.cleaned)
                .resizable()
                .scaledToFit()
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .onTapGesture { showOriginal.toggle() }

            HStack {
                Text(showOriginal ? "Ảnh gốc (chạm để đổi)" : "Ảnh sạch (chạm để xem ảnh gốc)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                ShareLink(
                    item: Image(uiImage: item.cleaned),
                    preview: SharePreview(item.name, image: Image(uiImage: item.cleaned))
                ) {
                    Label("Chia sẻ", systemImage: "square.and.arrow.up")
                        .font(.subheadline)
                }
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
