import SwiftUI

struct ProjectsView: View {
    @EnvironmentObject var projects: ProjectStore
    @State private var showNew = false
    @State private var showSettings = false
    @State private var toDelete: Project?

    var body: some View {
        NavigationStack {
            List {
                if projects.projects.isEmpty {
                    Text("Chưa có dự án nào. Bấm + để tạo dự án đầu tiên.")
                        .foregroundStyle(.secondary)
                }
                ForEach(projects.projects) { p in
                    Button {
                        projects.activeSlug = p.slug
                    } label: {
                        ProjectRow(project: p, isActive: p.slug == projects.activeSlug)
                    }
                    .buttonStyle(.plain)
                    .swipeActions {
                        Button("Xóa", role: .destructive) { toDelete = p }
                    }
                }
                if let a = projects.active {
                    Section("Thư mục dự án") {
                        Button {
                            if let url = URL(string: "shareddocuments://" + a.dir.path) {
                                UIApplication.shared.open(url)
                            }
                        } label: { Label("Mở trong app Tệp", systemImage: "folder") }
                        Text("Tệp > Trên iPhone > Editor AI > Projects > \(a.slug)")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Dự án")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button { showSettings = true } label: { Image(systemName: "gearshape") }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showNew = true } label: { Image(systemName: "plus") }
                }
            }
            .onAppear { projects.reload() }
        }
        .sheet(isPresented: $showNew) { NewProjectSheet() }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .alert("Xóa dự án?", isPresented: Binding(get: { toDelete != nil }, set: { if !$0 { toDelete = nil } })) {
            Button("Xóa", role: .destructive) {
                if let p = toDelete { projects.delete(p) }
                toDelete = nil
            }
            Button("Hủy", role: .cancel) { toDelete = nil }
        } message: {
            Text("Toàn bộ ảnh, giọng đọc, kịch bản và video của «\(toDelete?.meta.name ?? "")» sẽ bị xóa.")
        }
    }
}

struct ProjectRow: View {
    let project: Project
    let isActive: Bool

    var body: some View {
        let clean = project.cleanImages.count
        let hasVoice = project.latestVoice != nil
        let hasSRT = project.latestSRT != nil
        let scenes = project.sceneCount
        let ready = clean > 0 && hasVoice && hasSRT && scenes > 0

        HStack(alignment: .top) {
            Image(systemName: isActive ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(isActive ? Color.blue : Color.secondary)
            VStack(alignment: .leading, spacing: 4) {
                Text(project.meta.name).font(.headline)
                Text("\(project.meta.aspect) · \(project.meta.fps) FPS")
                    .font(.caption).foregroundStyle(.secondary)
                Text("Ảnh sạch: \(clean) · Voice: \(hasVoice ? "có" : "chưa") · SRT: \(hasSRT ? "có" : "chưa") · Cảnh: \(scenes)")
                    .font(.caption).foregroundStyle(.secondary)
                if ready {
                    Text("Sẵn sàng dựng video").font(.caption.weight(.semibold)).foregroundStyle(.green)
                }
            }
        }
    }
}

struct NewProjectSheet: View {
    @EnvironmentObject var projects: ProjectStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var aspect = "16:9"
    @State private var fps = 30
    @State private var error: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("Tên dự án") {
                    TextField("Ví dụ: Người que tập 1", text: $name)
                }
                Section("Khung hình") {
                    Picker("Tỉ lệ", selection: $aspect) {
                        Text("16:9").tag("16:9")
                        Text("9:16").tag("9:16")
                        Text("1:1").tag("1:1")
                    }
                    .pickerStyle(.segmented)
                    Picker("FPS", selection: $fps) {
                        ForEach([24, 25, 30, 60], id: \.self) { Text("\($0)").tag($0) }
                    }
                    .pickerStyle(.segmented)
                }
                if let error = error {
                    Text(error).foregroundStyle(.red).font(.footnote)
                }
            }
            .navigationTitle("Dự án mới")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Hủy") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Tạo") {
                        do {
                            try projects.create(name: name, aspect: aspect, fps: fps)
                            dismiss()
                        } catch {
                            self.error = "Không tạo được dự án: \(error.localizedDescription)"
                        }
                    }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }
}
