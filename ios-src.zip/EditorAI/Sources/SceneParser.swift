import Foundation

struct SceneError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct SceneItem {
    var id: String
    var prompt: String
    var subtitles: [Int]
    var startAt: String?
    var endAt: String?
    var motionType: String
    var motionStrength: String
}

/// Port từ video_creator.parse_json_data (bản desktop).
enum SceneParser {
    static let motionTypes: Set<String> = [
        "none", "zoom_in", "zoom_out", "pan_left", "pan_right", "pan_up",
        "pan_down", "drift_left", "drift_right", "shake"
    ]
    static let motionStrengths: Set<String> = ["subtle", "medium"]
    private static let timedFields: Set<String> = [
        "id", "character", "character_info", "prompt", "subtitle_ids", "start_at", "end_at"
    ]

    static func intValue(_ any: Any) -> Int? {
        guard let n = any as? NSNumber,
              CFGetTypeID(n) != CFBooleanGetTypeID(),
              !CFNumberIsFloatType(n as CFNumber) else { return nil }
        return n.intValue
    }

    static func parseSubString(_ s: String) -> [Int] {
        var result = Set<Int>()
        for part in s.components(separatedBy: ",") {
            let p = part.trimmingCharacters(in: .whitespaces)
            if p.contains("-") {
                let ab = p.split(separator: "-", maxSplits: 1).map(String.init)
                if ab.count == 2, let a = Int(ab[0].trimmingCharacters(in: .whitespaces)),
                   let b = Int(ab[1].trimmingCharacters(in: .whitespaces)), a <= b {
                    for i in a...b { result.insert(i) }
                }
            } else if let v = Int(p) {
                result.insert(v)
            }
        }
        return result.sorted()
    }

    static func motion(_ v: Any?) -> (String, String) {
        if let d = v as? [String: Any],
           let t = d["type"] as? String, let s = d["strength"] as? String,
           motionTypes.contains(t), motionStrengths.contains(s) {
            return (t, s)
        }
        return ("none", "subtle")
    }

    static func parse(text: String) throws -> [SceneItem] {
        guard let data = text.data(using: .utf8) else { throw SceneError(message: "Không đọc được nội dung.") }
        let obj: Any
        do {
            obj = try JSONSerialization.jsonObject(with: data, options: [.fragmentsAllowed])
        } catch {
            throw SceneError(message: "sai cú pháp JSON (kiểm tra dấu ngoặc, dấu phẩy, dấu nháy).")
        }
        return try parse(obj)
    }

    static func srtSeconds(_ s: String) -> Double? { SRT.parse(s) }

    static func parse(_ raw: Any) throws -> [SceneItem] {
        let timePattern = "^\\d{2}:\\d{2}:\\d{2},\\d{3}$"
        func isTime(_ s: String) -> Bool { s.range(of: timePattern, options: .regularExpression) != nil }

        // Định dạng có start_at / end_at
        if let list = raw as? [Any],
           list.contains(where: { item in
               guard let d = item as? [String: Any] else { return false }
               return ["character", "character_info", "start_at", "end_at"].contains(where: { d[$0] != nil })
           }) {
            var scenes: [SceneItem] = []
            var previousEnd: String?
            for (i, anyItem) in list.enumerated() {
                let index = i + 1
                guard let item = anyItem as? [String: Any],
                      Set(item.keys).subtracting(["motion"]) == timedFields else {
                    throw SceneError(message: "Mỗi cảnh phải có đủ 7 trường: id, character, character_info, prompt, subtitle_ids, start_at, end_at (motion là tùy chọn).")
                }
                let expected = String(format: "SC%02d", index)
                guard let id = item["id"] as? String, id == expected else {
                    throw SceneError(message: "ID cảnh thứ \(index) phải là \(expected).")
                }
                guard let prompt = item["prompt"] as? String,
                      item["character"] is String, item["character_info"] is String else {
                    throw SceneError(message: "character, character_info và prompt phải là chuỗi.")
                }
                guard let subArr = item["subtitle_ids"] as? [Any] else {
                    throw SceneError(message: "subtitle_ids phải là mảng số nguyên.")
                }
                var subs: [Int] = []
                for s in subArr {
                    guard let v = intValue(s) else { throw SceneError(message: "subtitle_ids phải là mảng số nguyên.") }
                    subs.append(v)
                }
                guard let startAt = item["start_at"] as? String, isTime(startAt) else {
                    throw SceneError(message: "start_at của \(id) không đúng định dạng HH:MM:SS,mmm.")
                }
                if index == 1 && startAt != "00:00:00,000" {
                    throw SceneError(message: "SC01 phải bắt đầu tại 00:00:00,000.")
                }
                if let pe = previousEnd, startAt != pe {
                    throw SceneError(message: "start_at của \(id) phải bằng end_at của cảnh trước.")
                }
                let isLast = index == list.count
                let endAt = item["end_at"] as? String ?? ""
                if isLast {
                    if endAt != "AUDIO_END" { throw SceneError(message: "Cảnh cuối phải có end_at là AUDIO_END.") }
                } else {
                    guard isTime(endAt) else {
                        throw SceneError(message: "end_at của \(id) không đúng định dạng HH:MM:SS,mmm.")
                    }
                    if let e = srtSeconds(endAt), let s = srtSeconds(startAt), e <= s {
                        throw SceneError(message: "end_at của \(id) phải sau start_at.")
                    }
                }
                let m = motion(item["motion"])
                scenes.append(SceneItem(id: id, prompt: prompt, subtitles: subs, startAt: startAt, endAt: endAt,
                                        motionType: m.0, motionStrength: m.1))
                previousEnd = endAt
            }
            return scenes
        }

        var scenes: [SceneItem] = []
        if let dict = raw as? [String: Any] {
            for (key, value) in dict.sorted(by: { $0.key < $1.key }) {
                var subs: [Int] = []
                if let v = intValue(value) { subs = [v] }
                else if let s = value as? String { subs = parseSubString(s) }
                else if let arr = value as? [Any] { subs = arr.compactMap { intValue($0) }.sorted() }
                scenes.append(SceneItem(id: key.trimmingCharacters(in: .whitespaces), prompt: "", subtitles: subs,
                                        startAt: nil, endAt: nil, motionType: "none", motionStrength: "subtle"))
            }
        } else if let list = raw as? [Any] {
            for (i, anyItem) in list.enumerated() {
                if let item = anyItem as? [String: Any] {
                    let id = (item["id"] as? String) ?? (item["scene"] as? String) ?? (item["name"] as? String)
                        ?? String(format: "SC%02d", i + 1)
                    let rawSubs = item["subtitles"] ?? item["subtitle_ids"] ?? item["subs"] ?? item["sub_ids"]
                    var subs: [Int] = []
                    if let v = rawSubs.flatMap({ intValue($0) }) { subs = [v] }
                    else if let s = rawSubs as? String { subs = parseSubString(s) }
                    else if let arr = rawSubs as? [Any] { subs = arr.compactMap { intValue($0) }.sorted() }
                    let m = motion(item["motion"])
                    scenes.append(SceneItem(id: id.trimmingCharacters(in: .whitespaces),
                                            prompt: item["prompt"] as? String ?? "", subtitles: subs,
                                            startAt: nil, endAt: nil, motionType: m.0, motionStrength: m.1))
                } else if let s = anyItem as? String {
                    scenes.append(SceneItem(id: s.trimmingCharacters(in: .whitespaces), prompt: "", subtitles: [],
                                            startAt: nil, endAt: nil, motionType: "none", motionStrength: "subtle"))
                }
            }
        }
        return scenes
    }
}
