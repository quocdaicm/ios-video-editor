import SwiftUI

private let providerNames: [(key: String, label: String)] = [
    ("elevenlabs", "ElevenLabs"), ("minimax", "MiniMax"), ("capcut", "CapCut")
]

private func models(for provider: String) -> [String] {
    switch provider {
    case "minimax": return ["speech-2.8-hd", "speech-2.8-turbo", "speech-2.6-hd", "speech-2.6-turbo", "speech-02-hd", "speech-01-hd"]
    case "capcut": return ["capcut"]
    default: return ["eleven_v3", "eleven_multilingual_v2", "eleven_flash_v2_5", "eleven_turbo_v2_5"]
    }
}

private func languages(for provider: String) -> [String] {
    switch provider {
    case "minimax": return ["Vietnamese", "English", "Chinese (Mandarin)", "Japanese", "French", "German", "Spanish"]
    case "capcut": return ["vi", "en", "zh", "id", "es", "pt", "ja", "th"]
    default: return ["vi", "en", "ja", "ko", "zh", "fr", "de", "es"]
    }
}

struct TTSView: View {
    @StateObject private var vm = TTSViewModel()
    @StateObject private var player = AudioPlayerModel()
    @EnvironmentObject var projects: ProjectStore
    @State private var info: String?

    @AppStorage("tts_provider") private var provider = "elevenlabs"
    @State private var model = "eleven_v3"
    @State private var language = "vi"
    @State private var voiceIDs: [String: String] = [:]
    @State private var stability = 0.5      // ElevenLabs: độ ổn định
    @State private var similarity = 0.75    // ElevenLabs: độ tương đồng / MiniMax: âm lượng
    @State private var pitch = 0.0          // MiniMax / CapCut: cao độ
    @State private var speed = 1.0
    @State private var exportSRT = true
    @State private var text = ""
    @State private var showVoiceLibrary = false

    private var voiceID: String { voiceIDs[provider] ?? "" }

    private var summary: String {
        let est = VibiClient.estimateCredits(text: text, provider: provider, model: model)
        let bal = vm.balance.map { String($0) } ?? "--"
        return "\(text.count) ký tự · \(est)/\(bal) credits"
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {
                    configCard
                    textCard
                    generateButton
                    if let err = vm.errorText {
                        Text(err).font(.footnote).foregroundStyle(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    if let audio = vm.audioURL { resultCard(audio) }
                }
                .padding()
            }
            .navigationTitle("Tạo giọng TTS")
            .navigationBarTitleDisplayMode(.inline)
            .scrollDismissesKeyboard(.interactively)
        }
        .alert("Thông báo", isPresented: Binding(get: { info != nil }, set: { if !$0 { info = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(info ?? "")
        }
        .sheet(isPresented: $showVoiceLibrary) {
            VoiceLibraryView(provider: provider) { v in
                voiceIDs[provider] = v.id
            }
        }
        .onAppear {
            for p in providerNames {
                let saved = UserDefaults.standard.string(forKey: "tts_voice_\(p.key)")
                voiceIDs[p.key] = saved ?? (p.key == "elevenlabs" ? "6adFm46eyy74snVn6YrT" : "")
            }
            applyProviderDefaults()
            Task { await vm.refreshBalance() }
        }
        .onChange(of: voiceIDs) { newValue in
            for (k, v) in newValue { UserDefaults.standard.set(v, forKey: "tts_voice_\(k)") }
        }
        .onChange(of: provider) { _ in
            player.stop()
            applyProviderDefaults()
        }
    }

    private func applyProviderDefaults() {
        model = models(for: provider)[0]
        language = languages(for: provider)[0]
        stability = provider == "elevenlabs" ? 0.5 : 0
        similarity = provider == "elevenlabs" ? 0.75 : 1.0
        pitch = 0
        speed = 1.0
    }

    // MARK: - Các khối giao diện

    private var configCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Picker("Nền tảng", selection: $provider) {
                ForEach(providerNames, id: \.key) { Text($0.label).tag($0.key) }
            }
            .pickerStyle(.segmented)

            HStack {
                if provider != "capcut" {
                    Picker("Model", selection: $model) {
                        ForEach(models(for: provider), id: \.self) { Text($0).tag($0) }
                    }
                    .pickerStyle(.menu)
                }
                Spacer()
                Picker("Ngôn ngữ", selection: $language) {
                    ForEach(languages(for: provider), id: \.self) { Text($0).tag($0) }
                }
                .pickerStyle(.menu)
            }

            HStack {
                TextField("Voice ID", text: Binding(
                    get: { voiceIDs[provider] ?? "" },
                    set: { voiceIDs[provider] = $0 }
                ))
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .padding(10)
                .background(Color(.tertiarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 8))

                Button { showVoiceLibrary = true } label: {
                    Label("Tìm giọng", systemImage: "magnifyingglass")
                        .font(.subheadline)
                }
                .buttonStyle(.bordered)
            }

            if provider == "elevenlabs" {
                sliderRow("Độ ổn định", value: $stability, range: 0...1, step: 0.01, fmt: "%.2f")
                sliderRow("Độ tương đồng", value: $similarity, range: 0...1, step: 0.01, fmt: "%.2f")
            } else {
                sliderRow("Cao độ", value: $pitch, range: -12...12, step: 1, fmt: "%.0f")
                if provider == "minimax" {
                    sliderRow("Âm lượng", value: $similarity, range: 0...1, step: 0.01, fmt: "%.2f")
                }
            }
            sliderRow("Tốc độ", value: $speed, range: 0.7...1.5, step: 0.01, fmt: "%.2fx")

            Toggle("Xuất phụ đề SRT", isOn: $exportSRT)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private func sliderRow(_ title: String, value: Binding<Double>, range: ClosedRange<Double>, step: Double, fmt: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text("\(title): \(String(format: fmt, value.wrappedValue))")
                .font(.footnote).foregroundStyle(.secondary)
            Slider(value: value, in: range, step: step)
        }
    }

    private var textCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Nội dung").font(.subheadline).foregroundStyle(.secondary)
            TextEditor(text: $text)
                .frame(minHeight: 160)
                .padding(6)
                .background(Color(.tertiarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 8))
            Text(summary).font(.caption).foregroundStyle(.secondary)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private var generateButton: some View {
        HStack(spacing: 10) {
            Button {
                start()
            } label: {
                HStack {
                    if vm.isRunning { ProgressView().tint(.white) }
                    Text(vm.isRunning ? vm.status : "Tạo giọng đọc").fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(canGenerate ? Color.blue : Color.gray)
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .disabled(!canGenerate)

            if vm.isRunning {
                Button("Hủy") { vm.cancel() }
                    .buttonStyle(.bordered)
                    .tint(.red)
            }
        }
    }

    private var canGenerate: Bool {
        !vm.isRunning
            && !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && !voiceID.trimmingCharacters(in: .whitespaces).isEmpty
    }

    private func start() {
        let settings: [String: Any]
        switch provider {
        case "minimax":
            settings = ["speed": speed, "pitch": Int(pitch.rounded()), "vol": similarity]
        case "capcut":
            settings = ["speed": speed, "pitch": Int(pitch.rounded())]
        default:
            settings = ["stability": stability, "similarity_boost": similarity, "speed": speed]
        }
        player.stop()
        vm.start(TTSParams(
            provider: provider, model: model, language: language,
            voiceID: voiceID.trimmingCharacters(in: .whitespaces),
            voiceSettings: settings,
            text: text.trimmingCharacters(in: .whitespacesAndNewlines),
            exportSRT: exportSRT))
    }

    private func copyReplacing(_ src: URL, to dst: URL) throws {
        if FileManager.default.fileExists(atPath: dst.path) { try FileManager.default.removeItem(at: dst) }
        try FileManager.default.copyItem(at: src, to: dst)
    }

    private func saveToProject(_ p: Project, _ audio: URL) {
        do {
            try copyReplacing(audio, to: p.voiceDir.appendingPathComponent("voice.mp3"))
            if let srt = vm.srtURL {
                try copyReplacing(srt, to: p.voiceDir.appendingPathComponent("voice.srt"))
            }
            info = "Đã lưu voice\(vm.srtURL != nil ? " và phụ đề" : "") vào dự án «\(p.meta.name)»."
        } catch {
            info = "Không lưu được: \(error.localizedDescription)"
        }
    }

    private func resultCard(_ audio: URL) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Kết quả").font(.headline)
            Button {
                player.toggle(fileURL: audio)
            } label: {
                Label(player.isPlaying ? "Dừng" : "Nghe thử",
                      systemImage: player.isPlaying ? "stop.fill" : "play.fill")
                    .frame(maxWidth: .infinity)
                    .padding(10)
                    .background(Color.green.opacity(0.15))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }

            HStack {
                ShareLink(item: audio) { Label("Chia sẻ MP3", systemImage: "square.and.arrow.up") }
                Spacer()
                if let srt = vm.srtURL {
                    ShareLink(item: srt) { Label("Chia sẻ SRT", systemImage: "captions.bubble") }
                }
            }
            .font(.subheadline)

            if let p = projects.active {
                Button {
                    saveToProject(p, audio)
                } label: {
                    Label("Lưu vào dự án «\(p.meta.name)»", systemImage: "tray.and.arrow.down")
                        .frame(maxWidth: .infinity)
                        .padding(10)
                        .background(Color.orange.opacity(0.18))
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                }
            }

            Button {
                let path = TTSViewModel.documentsDir.path
                if let url = URL(string: "shareddocuments://" + path) {
                    UIApplication.shared.open(url)
                }
            } label: {
                Label("Mở thư mục trong app Tệp", systemImage: "folder")
                    .font(.subheadline)
            }
            Text("File được lưu trong Tệp > Trên iPhone > Editor AI > Voice.")
                .font(.caption).foregroundStyle(.secondary)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - Thư viện giọng

struct VoiceLibraryView: View {
    let provider: String
    let onSelect: (VoiceInfo) -> Void

    @Environment(\.dismiss) private var dismiss
    @StateObject private var player = AudioPlayerModel()
    @State private var query = ""
    @State private var voices: [VoiceInfo] = []
    @State private var page = 0
    @State private var hasMore = false
    @State private var loading = false
    @State private var error: String?

    var body: some View {
        NavigationStack {
            List {
                if let error = error {
                    Text(error).foregroundStyle(.red).font(.footnote)
                }
                ForEach(voices) { v in
                    HStack(alignment: .top, spacing: 10) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(v.name).font(.headline)
                            Text("\(v.gender) · \(v.language)").font(.caption).foregroundStyle(.secondary)
                            if !v.desc.isEmpty {
                                Text(v.desc).font(.caption2).foregroundStyle(.secondary).lineLimit(2)
                            }
                            Text(v.id).font(.caption2).foregroundStyle(.tertiary)
                        }
                        Spacer()
                        if !v.previewURL.isEmpty {
                            Button { player.toggle(remoteURL: v.previewURL) } label: {
                                Image(systemName: "play.circle").font(.title2)
                            }
                            .buttonStyle(.borderless)
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        player.stop()
                        onSelect(v)
                        dismiss()
                    }
                }
                if loading {
                    HStack { Spacer(); ProgressView(); Spacer() }
                } else if hasMore {
                    Button("Tải thêm") { Task { await load(reset: false) } }
                }
            }
            .navigationTitle("Chọn giọng")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, prompt: "Tìm theo tên, giới tính, ngôn ngữ...")
            .onSubmit(of: .search) { Task { await load(reset: true) } }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Đóng") { player.stop(); dismiss() }
                }
            }
        }
        .task { await load(reset: true) }
    }

    private func load(reset: Bool) async {
        if reset { page = 0; voices = [] }
        loading = true
        error = nil
        defer { loading = false }
        do {
            let r = try await VibiClient.shared.searchVoices(provider: provider, search: query, page: page)
            voices += r.voices
            hasMore = r.hasMore
            page += 1
        } catch {
            self.error = error.localizedDescription
        }
    }
}
